from flask import render_template, request, abort
from models import db, Stacja, Postoj, Trasa, Pociag
from sqlalchemy.orm import aliased
import datetime

def time_to_minutes(t):
    return t.hour * 60 + t.minute

def format_minutes(m):
    hours = m // 60
    minutes = m % 60
    if hours > 0:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"

def get_pociag_info(id_trasy):
    # Pobranie pociągu powiązanego lub domyślny fallback
    p = Pociag.query.get(id_trasy) or Pociag.query.first()
    return {
        'kategoria': p.kategoria if p else "REG",
        'nazwa': p.nazwa if p else f"Pociąg {id_trasy}"
    }

def register_routes(app):
    @app.route('/')
    def index():
        wszystkie_stacje = Stacja.query.order_by(Stacja.nazwa_stacji).all()
        domyslna_data = datetime.date.today().strftime('%Y-%m-%d')
        return render_template('index.html', stacje=wszystkie_stacje, domyslna_data=domyslna_data)

    @app.route('/szukaj', methods=['POST'])
    def szukaj():
        start_id = request.form.get('stacja_start')
        koniec_id = request.form.get('stacja_koniec')
        data_podrozy = request.form.get('data')
        godzina_input_str = request.form.get('godzina') or "00:00"
        
        if not start_id or not koniec_id:
            return "Błąd: Wybierz stację początkową i końcową!", 400
            
        start_id = int(start_id)
        koniec_id = int(koniec_id)
        
        try:
            h, m = map(int, godzina_input_str.split(':'))
            godzina_input = datetime.time(h, m)
        except ValueError:
            godzina_input = datetime.time(0, 0)

        polaczenia_dict = {}

        # 1. WYSZUKANIE POŁĄCZEŃ BEZPOŚREDNICH
        p_start = aliased(Postoj)
        p_koniec = aliased(Postoj)
        
        direct_rows = db.session.query(Trasa, p_start, p_koniec).\
            join(p_start, Trasa.id_trasy == p_start.id_trasy).\
            join(p_koniec, Trasa.id_trasy == p_koniec.id_trasy).\
            filter(p_start.id_stacji == start_id).\
            filter(p_koniec.id_stacji == koniec_id).\
            filter(p_start.numer_postoju < p_koniec.numer_postoju).\
            filter(p_start.godzina_odjazdu >= godzina_input).all()

        for trasa, ps, pk in direct_rows:
            m_start = time_to_minutes(ps.godzina_odjazdu)
            m_koniec = time_to_minutes(pk.godzina_przyjazdu)
            duration = m_koniec - m_start
            if duration < 0:
                duration += 1440  # Obsługa przejazdu przez północ
            
            # Klucz unikalny zapobiega duplikacji identycznych kursów
            key = ('direct', trasa.id_trasy, ps.godzina_odjazdu)
            if key not in polaczenia_dict:
                polaczenia_dict[key] = {
                    'type': 'direct',
                    'id_trasy': trasa.id_trasy,
                    'odjazd': ps.godzina_odjazdu.strftime('%H:%M'),
                    'przyjazd': pk.godzina_przyjazdu.strftime('%H:%M'),
                    'czas_trwania': format_minutes(duration),
                    'total_minutes': duration,
                    'pociag': get_pociag_info(trasa.id_trasy),
                    'route_name': trasa.nazwa_trasy
                }

        # 2. WYSZUKANIE POŁĄCZEŃ Z PRZESIADKĄ (1 PRZESIADKA)
        p1 = aliased(Postoj)  # Stacja początkowa na trasie 1
        p2 = aliased(Postoj)  # Stacja przesiadkowa na trasie 1
        p3 = aliased(Postoj)  # Stacja przesiadkowa na trasie 2
        p4 = aliased(Postoj)  # Stacja końcowa na trasie 2
        t1 = aliased(Trasa)
        t2 = aliased(Trasa)

        transfer_rows = db.session.query(t1, p1, p2, t2, p3, p4).\
            join(p1, t1.id_trasy == p1.id_trasy).\
            join(p2, t1.id_trasy == p2.id_trasy).\
            join(p3, t2.id_trasy == p3.id_trasy).\
            join(p4, t2.id_trasy == p4.id_trasy).\
            filter(p1.id_stacji == start_id).\
            filter(p2.id_stacji == p3.id_stacji).\
            filter(p4.id_stacji == koniec_id).\
            filter(p1.numer_postoju < p2.numer_postoju).\
            filter(p3.numer_postoju < p4.numer_postoju).\
            filter(t1.id_trasy != t2.id_trasy).\
            filter(p1.godzina_odjazdu >= godzina_input).\
            filter(p3.godzina_odjazdu >= p2.godzina_przyjazdu).all()

        for train1, pos1, pos2, train2, pos3, pos4 in transfer_rows:
            m_dep = time_to_minutes(pos1.godzina_odjazdu)
            m_arr = time_to_minutes(pos4.godzina_przyjazdu)
            duration = m_arr - m_dep
            if duration < 0:
                duration += 1440
            
            key = ('transfer', train1.id_trasy, train2.id_trasy, pos1.godzina_odjazdu, pos3.godzina_odjazdu)
            if key not in polaczenia_dict:
                stacja_przesiadki = Stacja.query.get(pos2.id_stacji).nazwa_stacji
                polaczenia_dict[key] = {
                    'type': 'transfer',
                    'id_trasy_1': train1.id_trasy,
                    'id_trasy_2': train2.id_trasy,
                    'odjazd': pos1.godzina_odjazdu.strftime('%H:%M'),
                    'przyjazd': pos4.godzina_przyjazdu.strftime('%H:%M'),
                    'czas_trwania': format_minutes(duration),
                    'total_minutes': duration,
                    'stacja_przesiadki': stacja_przesiadki,
                    'przyjazd_przesiadka': pos2.godzina_przyjazdu.strftime('%H:%M'),
                    'odjazd_przesiadka': pos3.godzina_odjazdu.strftime('%H:%M'),
                    'pociag1': get_pociag_info(train1.id_trasy),
                    'pociag2': get_pociag_info(train2.id_trasy)
                }

        # 3. FILTROWANIE DWUKROTNOŚCI NAJKRÓTSZEGO CZASU PRZEJAZDU
        all_options = list(polaczenia_dict.values())
        if all_options:
            min_duration = min(opt['total_minutes'] for opt in all_options)
            max_allowed_duration = 2 * min_duration
            # Zostawiamy tylko te, które nie przekraczają 2-krotności najkrótszego czasu
            filtered_options = [opt for opt in all_options if opt['total_minutes'] <= max_allowed_duration]
            filtered_options.sort(key=lambda x: x['odjazd'])
        else:
            filtered_options = []

        stacja_start_nazwa = Stacja.query.get(start_id).nazwa_stacji
        stacja_koniec_nazwa = Stacja.query.get(koniec_id).nazwa_stacji

        return render_template('wyniki.html', 
                               polaczenia=filtered_options, 
                               start=stacja_start_nazwa, 
                               koniec=stacja_koniec_nazwa, 
                               data=data_podrozy)

    @app.route('/szczegoly/direct/<int:id_trasy>')
    def szczegoly_direct(id_trasy):
        trasa = Trasa.query.get_or_404(id_trasy)
        data_podrozy = request.args.get('data')
        postoje_trasy = Postoj.query.filter_by(id_trasy=id_trasy).order_by(Postoj.numer_postoju).all()
        
        harmonogram = []
        for p in postoje_trasy:
            stacja = Stacja.query.get(p.id_stacji)
            harmonogram.append({
                'numer': p.numer_postoju,
                'stacja': stacja.nazwa_stacji if stacja else "Nieznana",
                'przyjazd': p.godzina_przyjazdu.strftime('%H:%M') if p.godzina_przyjazdu else 'Początek',
                'odjazd': p.godzina_odjazdu.strftime('%H:%M') if p.godzina_odjazdu else 'Koniec'
            })
        return render_template('szczegoly_direct.html', trasa=trasa, harmonogram=harmonogram, pociag=get_pociag_info(id_trasy), data=data_podrozy)

    @app.route('/szczegoly/transfer/<int:id1>/<int:id2>')
    def szczegoly_transfer(id1, id2):
        trasa1 = Trasa.query.get_or_404(id1)
        trasa2 = Trasa.query.get_or_404(id2)
        data_podrozy = request.args.get('data')
        
        def get_stops(id_trasy):
            postoje = Postoj.query.filter_by(id_trasy=id_trasy).order_by(Postoj.numer_postoju).all()
            res = []
            for p in postoje:
                stacja = Stacja.query.get(p.id_stacji)
                res.append({
                    'numer': p.numer_postoju,
                    'stacja': stacja.nazwa_stacji if stacja else "Nieznana",
                    'przyjazd': p.godzina_przyjazdu.strftime('%H:%M') if p.godzina_przyjazdu else 'Początek',
                    'odjazd': p.godzina_odjazdu.strftime('%H:%M') if p.godzina_odjazdu else 'Koniec'
                })
            return res

        return render_template('szczegoly_transfer.html', 
                               trasa1=trasa1, pociag1=get_pociag_info(id1), h1=get_stops(id1),
                               trasa2=trasa2, pociag2=get_pociag_info(id2), h2=get_stops(id2),
                               data=data_podrozy)





        